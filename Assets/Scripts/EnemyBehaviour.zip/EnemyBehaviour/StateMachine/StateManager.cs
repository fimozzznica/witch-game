using UnityEngine;
using UnityEngine.AI;

namespace EnemyBehaviour.StateMachine
{
    public class StateManager : MonoBehaviour
    {
        [SerializeField] private NavMeshAgent agent;
        [SerializeField] private Transform playerTransform;

        [SerializeField] public float patrolSpeed = 1.5f;
        [SerializeField] public float chaseSpeed = 3.5f;
        [SerializeField] public float retreatSpeed = 4f;

        [SerializeField] public float agroDistance = 10f;
        [SerializeField] public float attackDistance = 2f;
        [SerializeField] public float retreatDistance = 1f;


        public BaseState currentState;
        public IdleState idleState = new IdleState();
        public AgroState agroState = new AgroState();
        public AttackState attackState = new AttackState();
        public RetreatState retreatState = new RetreatState();

        public Vector3 originalPosition;
        
        public Transform Target { get => playerTransform; }


        private void Start()
        {
            SwitchState(idleState);
        }

        private void Update()
        {
            if (currentState != null && playerTransform != null)
            {
                currentState.UpdateState(this);
            }
        }

        public void SwitchState(BaseState newState)
        {
            currentState?.ExitState(this);
            currentState = newState;
            currentState.EnterState(this);
        }

        public void SetSpeed(float speed)
        {
            if (agent != null)
                agent.speed = speed;
        }

        public void SetDestination(Vector3 destination)
        {
            if (agent != null && agent.isActiveAndEnabled)
                agent.SetDestination(destination);
        }
        
        public float DistanceToTarget()
        {
            if (playerTransform == null)
                return float.MaxValue;

            return Vector3.Distance(transform.position, playerTransform.position);
        }
    }
}
