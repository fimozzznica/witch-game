using UnityEngine;

namespace EnemyBehaviour.StateMachine
{
    public class AttackState : BaseState
    {
        private float attackDuration = 3f;
        private float attackTimer = 0f;

        public override void EnterState(StateManager stateManager)
        {
            stateManager.SetSpeed(0);
            attackTimer = 0f;
        }

        public override void ExitState(StateManager stateManager)
        {
        }

        public override void UpdateState(StateManager stateManager)
        {
            if (stateManager.DistanceToTarget() > stateManager.attackDistance)
            {
                stateManager.SwitchState(stateManager.agroState);
                return;
            }
            if (stateManager.DistanceToTarget() < stateManager.retreatDistance)
            {
                stateManager.SwitchState(stateManager.retreatState);
                return;
            }

            attackTimer += Time.deltaTime;

            if (attackTimer >= attackDuration)
            {
                stateManager.SwitchState(stateManager.retreatState);
            }
        }
    }
}
