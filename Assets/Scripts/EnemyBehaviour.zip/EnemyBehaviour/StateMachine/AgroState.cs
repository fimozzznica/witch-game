using UnityEngine;

namespace EnemyBehaviour.StateMachine
{
    public class AgroState : BaseState
    {
        public override void EnterState(StateManager stateManager)
        {
            stateManager.SetSpeed(stateManager.chaseSpeed);
        }

        public override void ExitState(StateManager stateManager)
        {
        }

        public override void UpdateState(StateManager stateManager)
        {
            if (stateManager.DistanceToTarget() > stateManager.agroDistance)
            {
                stateManager.SwitchState(stateManager.idleState);
                return;
            }

            if (stateManager.DistanceToTarget() < stateManager.retreatDistance)
            {
                stateManager.SwitchState(stateManager.retreatState);
                return;
            }

            stateManager.SetDestination(stateManager.Target.position);
        }
    }
}
