using UnityEngine;

namespace EnemyBehaviour.StateMachine
{
    public class IdleState : BaseState
    {
        private Vector3 startPosition;
        private Vector3 targetPoint;
        private float patrolRadius = 5f;
        private float waitTime = 2f;
        private float patrolTimer = 0f;
        private bool isWaiting = false;

        public override void EnterState(StateManager stateManager)
        {
            startPosition = stateManager.transform.position;

            stateManager.SetSpeed(stateManager.patrolSpeed);

            ChooseNewPatrolPoint(stateManager);

        }

        public override void ExitState(StateManager stateManager)
        {
        }

        public override void UpdateState(StateManager stateManager)
        {
            if (stateManager.DistanceToTarget() < stateManager.agroDistance)
            {
                stateManager.SwitchState(stateManager.agroState);
                return;
            }

            if (isWaiting)
            {
                patrolTimer += Time.deltaTime;
                if (patrolTimer >= waitTime)
                {
                    isWaiting = false;
                    patrolTimer = 0f;
                    ChooseNewPatrolPoint(stateManager);
                    stateManager.SetSpeed(stateManager.patrolSpeed);
                }
            }
            else
            {
                if (Vector3.Distance(stateManager.transform.position, targetPoint) < 0.5f)
                {
                    isWaiting = true;
                    stateManager.SetSpeed(0);
                }
            }
        }

        private void ChooseNewPatrolPoint(StateManager stateManager)
        {
            Vector2 randomCircle = Random.insideUnitCircle * patrolRadius;
            targetPoint = startPosition + new Vector3(randomCircle.x, 0, randomCircle.y);
            stateManager.SetDestination(targetPoint);
        }
    }
}
